import React, { Component } from 'react';
import { View, ScrollView, StyleSheet } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useColorScheme } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import Loading from '../components/Loading/Loading';
import Header from '../components/Header/Header';
import NewsSection from '../components/NewsSection/NewsSection';
import { QueryClient, QueryClientProvider, QueryObserver, QueryObserverResult } from '@tanstack/react-query';
import { fetchBreakingNews, fetchRecommendedNews } from '../../utils/NewsApi';
import MiniHeader from '../components/Header/MiniHeader';
import { heightPercentageToDP as hp } from 'react-native-responsive-screen';
import BreakingNews from '../components/BreakingNews';

// Define types for news articles and responses
type Article = {
  title: string;
  description: string;
  url: string;
  urlToImage: string;
  // Add other article properties as needed
};

type NewsResponse = {
  articles: Article[];
};

interface HomeScreenState {
  breakingData?: NewsResponse;
  recommendedData?: NewsResponse;
  isBreakingLoading: boolean;
  isRecommendedLoading: boolean;
}

const queryClient = new QueryClient();

class HomeScreen extends Component<{}, HomeScreenState> {
  state: HomeScreenState = {
    breakingData: undefined,
    recommendedData: undefined,
    isBreakingLoading: true,
    isRecommendedLoading: true,
  };

  componentDidMount() {
    this.fetchBreakingNews();
    this.fetchRecommendedNews();
  }

  fetchBreakingNews = async () => {
    const observer = new QueryObserver(queryClient, {
      queryKey: ['breakingNews'],
      queryFn: fetchBreakingNews,
    });

    const result: QueryObserverResult<NewsResponse> = await observer.refetch();
    this.setState({
      breakingData: result.data,
      isBreakingLoading: result.isLoading,
    });
  };

  fetchRecommendedNews = async () => {
    const observer = new QueryObserver(queryClient, {
      queryKey: ['recommendedNews'],
      queryFn: fetchRecommendedNews,
    });

    const result: QueryObserverResult<NewsResponse> = await observer.refetch();
    this.setState({
      recommendedData: result.data,
      isRecommendedLoading: result.isLoading,
    });
  };

  render() {
    const { breakingData, recommendedData, isBreakingLoading, isRecommendedLoading } = this.state;
    const colorScheme = useColorScheme();
    const isDarkMode = colorScheme === 'dark';

    return (
      <SafeAreaView style={[styles.safeArea, isDarkMode ? styles.darkBackground : styles.lightBackground]}>
        <StatusBar style={isDarkMode ? 'light' : 'dark'} />

        <View>
          {/* Header */}
          <Header />

          {/* Breaking News */}
          {isBreakingLoading ? (
            <Loading />
          ) : (
            <View>
              <MiniHeader label="Breaking News" />
              {breakingData && <BreakingNews label="Breaking News" data={breakingData.articles} />}
            </View>
          )}

          {/* Recommended News */}
          <View>
            <MiniHeader label="Recommended" />
            <ScrollView
              contentContainerStyle={{
                paddingBottom: hp(80),
              }}
            >
              {isRecommendedLoading ? (
                <Loading />
              ) : (
                recommendedData && <NewsSection label="Recommendation" newsProps={recommendedData.articles} />
              )}
            </ScrollView>
          </View>
        </View>
      </SafeAreaView>
    );
  }
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
  },
  lightBackground: {
    backgroundColor: 'white',
  },
  darkBackground: {
    backgroundColor: '#1c1c1e',
  },
});

export default () => (
  <QueryClientProvider client={queryClient}>
    <HomeScreen />
  </QueryClientProvider>
);

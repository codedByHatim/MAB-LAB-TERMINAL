export const newsApiKey = "d3a95665ea6d4889bf756b43760707e3";
